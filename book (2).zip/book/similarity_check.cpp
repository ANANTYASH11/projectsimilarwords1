#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <set>
#include <algorithm>
#include <tuple>

using namespace std;


unordered_map<string, double> getTop100FrequentWords(const string &filename);
double calculateSimilarity(const unordered_map<string, double> &freq1, const unordered_map<string, double> &freq2);
void printTopSimilarPairs(double similarity_matrix[64][64], int num_books);

const set<string> IGNORED_WORDS = {"a", "and", "an", "of", "in", "the"};

int main() {
    const int num_books = 64;
    vector<unordered_map<string, double>> book_word_frequencies(num_books);
    double similarity_matrix[num_books][num_books] = {0};

    
    for (int i = 0; i < num_books; ++i) {
        string filename = "book" + to_string(i + 1) + ".txt";
        book_word_frequencies[i] = getTop100FrequentWords(filename);

        if (book_word_frequencies[i].empty()) {
            cerr << "Skipping file " << filename << endl;
            continue;
        }
    }

   
    for (int i = 0; i < num_books; ++i) {
        for (int j = 0; j < num_books; ++j) {
            if (i != j && !book_word_frequencies[i].empty() && !book_word_frequencies[j].empty()) {
                similarity_matrix[i][j] = calculateSimilarity(book_word_frequencies[i], book_word_frequencies[j]);
            }
        }
    }

    
    printTopSimilarPairs(similarity_matrix, num_books);

    return 0;
}

unordered_map<string, double> getTop100FrequentWords(const string &filename) {
    unordered_map<string, int> word_count;
    ifstream file(filename);
    string word;
    int total_words = 0;

    while (file >> word) {
        string normalized;
        for (char ch : word) {
            if (isalnum(ch)) {
                normalized += toupper(ch);
            }
        }
        if (!IGNORED_WORDS.count(normalized) && !normalized.empty()) {
            word_count[normalized]++;
            total_words++;
        }
    }

    unordered_map<string, double> word_freq;
    for (const auto &entry : word_count) {
        word_freq[entry.first] = static_cast<double>(entry.second) / total_words;
    }

    vector<pair<string, double>> freq_vec(word_freq.begin(), word_freq.end());
    sort(freq_vec.begin(), freq_vec.end(), [](const auto &a, const auto &b) {
        return b.second > a.second;
    });

    unordered_map<string, double> top_100_freq;
    for (int i = 0; i < min(100, (int)freq_vec.size()); ++i) {
        top_100_freq[freq_vec[i].first] = freq_vec[i].second;
    }

    return top_100_freq;
}

double calculateSimilarity(const unordered_map<string, double> &freq1, const unordered_map<string, double> &freq2) {
    double similarity = 0.0;
    for (const auto &entry : freq1) {
        if (freq2.count(entry.first)) {
            similarity += min(entry.second, freq2.at(entry.first));
        }
    }
    return similarity;
}

void printTopSimilarPairs(double similarity_matrix[64][64], int num_books) {
    vector<tuple<int, int, double>> similarity_pairs;
    for (int i = 0; i < num_books; ++i) {
        for (int j = i + 1; j < num_books; ++j) {
            similarity_pairs.emplace_back(i, j, similarity_matrix[i][j]);
        }
    }

    sort(similarity_pairs.begin(), similarity_pairs.end(), [](const auto &a, const auto &b) {
        return get<2>(a) > get<2>(b);
    });

    cout << "Top 10 similar pairs of books:" << endl;
    for (int i = 0; i < 10 && i < similarity_pairs.size(); ++i) {
        int book1 = get<0>(similarity_pairs[i]) + 1;
        int book2 = get<1>(similarity_pairs[i]) + 1;
        double similarity = get<2>(similarity_pairs[i]);
        cout << "Book " << book1 << " and Book " << book2 << " - Similarity: " << similarity << endl;
    }
}
